setwd(".")
library(ggplot2)

data4 <- data.frame(
  A = c("Pseudogene/ambiguous", "5' to known gene", "Novel", "Within or 3' flanking to a known gene"),
  B = c(17, 22, 24, 36)
)

Regions <- c("lightblue", "purple", "lightyellow", "maroon")

ggplot(data4, aes(x = A, y = B, fill = A)) +
  geom_col() +
  scale_fill_manual(values = c(
    "Pseudogene/ambiguous" = "lightblue",
    "5' to known gene" = "purple",
    "Novel" = "lightyellow",
    "Within or 3' flanking to a known gene" = "maroon"
  )) +
  labs(x = NULL, y = "Distribution of all TFBS Regions") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  )

dataAM <- readRDS("./BRFSS2023.RDS")
summary(dataAM$x.state)
(dataAM$x.bmi5cat)

library(dplyr)

# na binnen bmi uit data halen
data_clean <- dataAM[!is.na(dataAM$x.bmi5cat), ]

# FIPS verwerking - heeft jammer veel tijd gekost
fips_to_name <- data.frame(x.state = sprintf("%02d", 1:51),staat = c(state.name, "District of Columbia"))
data_clean$x.state <- sprintf("%02d", as.integer(data_clean$x.state))
data_clean <- merge(data_clean, fips_to_name, by = "x.state", all.x = TRUE)

# faceted barplot van bmi en staat
ggplot(data_clean, aes(x = x.bmi5cat, fill = x.bmi5cat)) +
  geom_bar() +
  facet_wrap(~ staat, scales = "free_y") +
  labs(x = "BMI Category", y = "Count", fill = "BMI Category") +
  theme_minimal()

# Dataset opgesteld in Excel, geëxporteerd naar csv waardoor geen preprocessing nodig is
KNMI <- read.csv("./KNMI.csv")
KNMI

ggplot(KNMI, aes(x=Jaartal, y=Temperatuur)) + 
  geom_line() + 
  geom_point() + 
  geom_smooth(colour= "red") + 
  theme_minimal()
 